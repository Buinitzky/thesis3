#ifndef _SOCKET_UDP_CLIENTE_H
#define _SOCKET_UDP_CLIENTE_H

void err(char *s);
int Enviar_Bandera(char *ip);

#endif
